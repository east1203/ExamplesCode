typedef class Packet;
typedef mailbox #(Packet) pkt_mbox;

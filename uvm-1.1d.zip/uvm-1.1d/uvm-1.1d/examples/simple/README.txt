This directory contains examples that exercise specific features of
the UVM library. As such, they are neither complete, exhaustive nor
necessarily fully compliant to the UVM methodology.

See the $UVM_HOME/examples/integrated directory for complete examples.

